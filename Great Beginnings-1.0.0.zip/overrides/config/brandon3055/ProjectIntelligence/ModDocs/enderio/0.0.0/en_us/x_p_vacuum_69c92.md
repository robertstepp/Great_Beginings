§stack[enderio:block_xp_vacuum]{size:18,enable_tooltip:false}

§recipe[enderio:block_xp_vacuum]{spacing:4}