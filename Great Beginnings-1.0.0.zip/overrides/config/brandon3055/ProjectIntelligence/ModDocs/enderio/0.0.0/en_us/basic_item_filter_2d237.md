§align:center
###### §nBasic Item Filter§n
§stack[enderio:item_basic_item_filter]{size:18,enable_tooltip:false} 
§align:left
The Basic Item Filter allows you to filter for up to 5 items. It can be switched between whitelist (only items listed are allowed) and blacklist (all items *but* the listed ones are allowed. It can also be set to ignore metadata, like the color of §stack[minecraft:wool,1,10]{size:9,enable_tooltip:false}§stack[minecraft:wool,1,9]{size:9,enable_tooltip:false}§stack[minecraft:wool,1,6]{size:9,enable_tooltip:false}wool.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}

§recipe[enderio:item_basic_item_filter]{spacing:4}