§stack[enderio:block_powered_spawner]{size:18,enable_tooltip:false}

§recipe[enderio:block_powered_spawner]{spacing:4}