§stack[enderio:block_farm_station]{size:18,enable_tooltip:false}

§recipe[enderio:block_farm_station]{spacing:4}