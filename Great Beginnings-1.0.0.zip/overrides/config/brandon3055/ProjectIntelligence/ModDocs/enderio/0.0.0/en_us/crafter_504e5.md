§stack[enderio:block_simple_crafter]{size:18,enable_tooltip:false}§stack[enderio:block_crafter]{size:18,enable_tooltip:false}

§recipe[enderio:block_simple_crafter]{spacing:4}
§recipe[enderio:block_crafter]{spacing:4}