§stack[enderio:block_power_monitor]{size:18,enable_tooltip:false}§stack[enderio:block_advanced_power_monitor]{size:18,enable_tooltip:false}

§recipe[enderio:block_power_monitor]{spacing:4}
§recipe[enderio:block_advanced_power_monitor]{spacing:4}