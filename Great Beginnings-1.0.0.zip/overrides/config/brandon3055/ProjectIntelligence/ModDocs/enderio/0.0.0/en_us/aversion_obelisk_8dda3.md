§stack[enderio:block_aversion_obelisk]{size:18,enable_tooltip:false}

§recipe[enderio:block_aversion_obelisk]{spacing:4}