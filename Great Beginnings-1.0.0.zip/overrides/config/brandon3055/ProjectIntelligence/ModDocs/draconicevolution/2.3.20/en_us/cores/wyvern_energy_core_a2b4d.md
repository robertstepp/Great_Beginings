§align:center
##### §Wyvern Energy Core§n

§stack[draconicevolution:wyvern_energy_core]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
This is a crafting component used to craft items or blocks that need to be able to store energy such as the RF powered tools and armor.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_energy_core]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}