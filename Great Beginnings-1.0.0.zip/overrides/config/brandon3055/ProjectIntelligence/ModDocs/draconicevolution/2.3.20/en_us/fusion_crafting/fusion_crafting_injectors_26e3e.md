§align:center
##### §nFusion Crafting Injectors§n

§stack[draconicevolution:crafting_injector]{size:42} §stack[draconicevolution:crafting_injector,1,1]{size:42} §stack[draconicevolution:crafting_injector,1,2]{size:42} §stack[draconicevolution:crafting_injector,1,3]{size:42}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Fusion crafting injectos are a key component in fusion crafting. These are used to hold the items to be fused with the catalyst. Check out the §link[draconicevolution:fusion_crafting/fusion_crafting_setup]{alt_text:"Fusion Crafting Setup"} page for setup information.

You can shift right click an injector with an empty hand to put it in single item mode. As the name suggests when in this mode the injector will only accept a single item as opposed to an entire stack. This can be helpful when automating fusion crafting.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:crafting_injector]{spacing:2} §recipe[draconicevolution:crafting_injector,1,1]{spacing:2} §recipe[draconicevolution:crafting_injector,1,2]{spacing:2} §recipe[draconicevolution:crafting_injector,1,3]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}