§align:center
##### §nDraconic Tools§n

§stack[draconicevolution:draconic_pick]{size:32} §stack[draconicevolution:draconic_axe]{size:32} §stack[draconicevolution:draconic_shovel]{size:32} §stack[draconicevolution:draconic_hoe]{size:32} §stack[draconicevolution:draconic_sword]{size:32} §stack[draconicevolution:draconic_bow]{size:32} §stack[draconicevolution:draconic_staff_of_power]{size:32} §stack[draconicevolution:draconium_capacitor,1,1]{size:32}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
These are the top tier Draconic Evolution tools and weapons.

These tools inherit all of the abilities of the Wyvern tools but the base stats are higher and they can accept draconic tier upgrades. 

§6§nAdjustable Dig Depth.§r
All of the mining tools have adjustable mining depth.
Meaning you can for example mine a 5x5x5 cube.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§img[https://raw.githubusercontent.com/brandon3055/Project-Intelligence-Docs/master/Assets/Draconic%20Evolution/Tools/Draconic%20Tools.jpg]{tooltip:"The wyvern toolset uses custom 3D models when rendered in game.",width:100%}
§rule{colour:0x606060,height:3,width:100%}