§align:center
##### §nEnergy Crystal Network§n

§img[http://ss.brandon3055.com/09010]{width:100%} 
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
The crystal network forms Draconic Evolution's energy transport system. To get started read up on §link[draconicevolution:energy_network/the_basics]{alt_text:"The Basics"}
§rule{colour:0x606060,height:3,width:100%,}