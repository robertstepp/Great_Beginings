§align:center
##### §nDraconic Boots§n

§stack[draconicevolution:draconic_boots]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

Fall protection
Jump boost (Configurable)
Uphill Step Assist (Configurable)
+60 Base Shield Capacity
+3 Armor Toughness
+3 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_boots]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}